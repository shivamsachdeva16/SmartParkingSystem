from django.apps import AppConfig


class ParConfig(AppConfig):
    name = 'par'
