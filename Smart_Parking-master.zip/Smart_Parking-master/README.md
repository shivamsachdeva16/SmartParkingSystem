# Smart_Parking
Smart Parking System architecture contains 3 phases:- 
1.Our own custom designed algorithm for single entry-exit gate for the vehicle. 
2.Data sending from parking slots(ir sensor) to our website. 
3.Receiveing OTP(One Time Password) from the data for the keypad to check the exit of user(Security mode). 
